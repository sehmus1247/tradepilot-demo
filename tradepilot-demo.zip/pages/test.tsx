import React from 'react';

const TestPage = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Strateji Test Sayfası</h1>
      <p>Buraya form, grafik ve AI analiz modülleri eklenecek.</p>
    </div>
  );
};

export default TestPage;